# TrafficsSignDetection
this is a C++ program for traffic signs detection supported by OpenCV
more infomation，please check http://lps-683.iteye.com/blog/2360806
